; File: WDC_CStartup_816.asm
; 10/07/2003

     PW 128         ;Page Width (# of char/line) 
     PL 60          ;Page Length for HP Laser
     INCLIST ON     ;Add Include files in Listing

				;*********************************************
				;Test for Valid Processor defined in -D option
				;*********************************************
	IF	USING_265
	ELSEIF	USING_816
	ELSEIF	USING_CDC16F 
	ELSE
		EXIT         "Not Valid Processor: Use -DUSING_816, etc. ! ! ! ! ! ! ! ! ! ! ! !"
	ENDIF


				;*********************************************
				;Test for Valid 'Model' type defined in -D option
				;*********************************************
	IF	SMALL
	ELSEIF	MEDIUM
	ELSEIF	COMPACT
	ELSEIF	LARGE
	ELSE
;		EXIT         "Not Valid 'Model' type - SMALL, MEDIUM, COMPACT, or LARGE: Use -DSMALL, etc. ! ! ! ! ! ! ! ! ! ! ! !"
	ENDIF

;****************************************************************************
;****************************************************************************
; End of testing for proper Command line Options for Assembly of this program
;****************************************************************************
;****************************************************************************


	IF	USING_265
		IF	SMALL
			title  "WDC 'C' Startup Program V 1.01 for Small Model W65C265 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	MEDIUM
			title  "WDC 'C' Startup Program V 1.01 for Medium Model W65C265 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	COMPACT
			title  "WDC 'C' Startup Program V 1.01 for Compact Model W65C265 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	LARGE
			title  "WDC 'C' Startup Program V 1.01 for Large Model W65C265 - WDC_CStartup_816.asm"
			sttl
		ENDIF
	ELSEIF	USING_816
		IF	SMALL
			title  "WDC 'C' Startup Program V 1.01 for Small Model W65C816 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	MEDIUM
			title  "WDC 'C' Startup Program V 1.01 for Medium Model W65C816 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	COMPACT
			title  "WDC 'C' Startup Program V 1.01 for Compact Model W65C816 - WDC_CStartup_816.asm"
			sttl
		ELSEIF	LARGE
			title  "WDC 'C' Startup Program V 1.01 for Large Model W65C816 - WDC_CStartup_816.asm"
			sttl
		ENDIF
	ENDIF


; bgnpkhdr
;***************************************************************************
;  FILE_NAME: WDC_CStartup_816.asm
;
;  DATA_RIGHTS: Western Design Center and R & C Services Proprietary
;               Copyright(C) 1980-2003
;               All rights reserved. Reproduction in any manner, 
;               in whole or in part, is strictly prohibited without
;               the prior written approval of R & C Services or 
;               Western Design Center.
;
;               Information contained in this publication regarding
;               device applications and the like is intended through
;               suggestion only and may be superseded by updates.  
;               It is your responsibility to ensure that your application
;               meets with your specifications.  No representation or
;               warranty is given and no liability is assumed by 
;               Western Design Center, Inc. with respect to the accuracy
;               or use of such information, or infringement of patents
;               or other intellectual property rights arising from such
;               use or otherwise.  Use of Western Design Center's products
;               as critical components in life support systems is not
;               authorized except with express written approval by
;               Western Design Center, Inc.'s.  No licenses are conveyed,
;               implicitly or otherwise, under any intellectual property rights.
;
;
;
;  TITLE: WDC_CStartup_816
;
;  DESCRIPTION: This File describes the WDC SDS General purpose ROM startup code.
;
;                Program Flow
;
;                First we make sure we are in native mode.
;                Then we set up the stack pointer.
;                Then we set the data bank register.
;                Then we copy the initialized data.
;                Then we clear out the uninitialized data.
;                Then we call main.
;
;  DEFINED FUNCTIONS:
;          Undefined_IRQ
;                   - Process a Bad Interrupt Vector - send code & Hang!
;
;
;  SPECIAL_CONSIDERATIONS:
;
;
;  SHARED_DATA:
;          None
;
;  GLOBAL_MODULES:
;          None
;
;  LOCAL_MODULES:
;          See above in "DEFINED FUNCTIONS"
;
;  AUTHOR: Jim Goodnow II
;
;  CREATION DATE: March 11,1997
;
;  REVISION HISTORY
;     Name           Date         Description
;     ------------   ----------   ------------------------------------------------
;     R. Greenthal   10/07/2003   1.01 Initial
;
;
;
; NOTE:
;    Change the lines for each version - current version is 1.01
;    See - 
;         title  "WDC 'C' Startup Program V 1.01 for Large Model W65C816 - WDC_CStartup_816.asm"
;
;
;***************************************************************************
;endpkhdr


;***************************************************************************
;                             Include Files
;***************************************************************************
;None


;***************************************************************************
;                              Global Modules
;***************************************************************************
;None

;***************************************************************************
;                              External Modules
;***************************************************************************
;None

;***************************************************************************
;                              External Variables
;***************************************************************************
;None


;***************************************************************************
;                               Local Constants
;***************************************************************************
;


	IF	USING_265
BCR:			equ	$df40		;Bus Control Register
SSCR:			equ	$df41		;System Speed Control Register
TCR:	           	equ     $DF42		;Timer Control Register
TER:	           	equ     $DF43		;Timer Enable Register
EIFR:			equ	$df45		;Edge Interrupt Flag Register
TIER:			equ	$DF46		;Timer IRQ Enable Reg
EIER:			equ	$df47		;Edge Interrupt Enable Register
UIER:			equ	$DF49		;UART IRQ Enable Reg

VIA_BASE:		equ	$DF000		;External VIA (65c22)
	ENDIF

;	.page

;***************************************************************************
;                          RAM Section
;***************************************************************************
;   



        sttl "WDC_CStartup_816 Code"
	.page

;***************************************************************************
;***************************************************************************
;                    WDC_CStartup_816 Code Section
;***************************************************************************
;***************************************************************************

****************************************************************
*                                                              *
*   Define a special section in case most of the               *
*      code is not in bank 0.                                  *
*                                                              *
****************************************************************
;           Small   Model Function Calls use module Function_Name  and xdef __Function_Name
;           Medium  Model Function Calls use module Function_Name  and xdef ~_Function_Name
;           Large   Model Function Calls use module Function_Name  and xdef ~~Function_Name
;           Compact Model Function Calls use module Function_Name  and xdef _~Function_Name



STACK   EQU   $01FF     ;CHANGE THIS FOR YOUR SYSTEM

STARTUP SECTION OFFSET $7D00

	IF	SMALL
		xdef	__START
__START:
	ELSEIF	MEDIUM
		xdef	~_START
~_START:
	ELSEIF	COMPACT
		xdef	_~START
_~START:
	ELSEIF	LARGE
		xdef	~~START
~~START:
	ENDIF

START:
	SEI
        CLC                ;clear carry
        XCE                ;clear emulation-Now in Native 16 bit Mode
        REP   #$38         ;16 bit registers and Clear Decimal mode
        LONGI ON
        LONGA ON
        LDA   #STACK       ;get the stack address
        TCS                ;and set the stack to it

****************************************************************
*                                                              *
*   Set up the data bank register. We assume that the data     *
*       section is where we want to point at.                  *
*                                                              *
****************************************************************

        SEP   #$20         ;8 bit accum
        LONGA OFF

	IF	USING_265
;		lda     #$e9		;Enable External ROM, NMI, Abort
;		sta     BCR             ; enable IRQ1, IRQ2, NMI
;		lda     #$80            ; enable IRQ2 flag
;		sta     EIER
					;********
					;WARNING:
					;********
					; SSCR Powers up as $00
					; This means the FCLK is Stopped!
					; PHI2 is CLK (32 KHZ)
					; and CS0B-CS7B set to CLK

					;Setup FCLK on 65c265
;		ldx     #$FD            ; bit 0,1 and 3 control FCLK/CLK to PHI2 (Start FCLK, PHI2 to CLK, CS5B set Fast?)
;		stx     SSCR		; bit 4 sets bank 00 to 3f to FCLK

;		ldx	#$100		;WAIT FOR FCLOCK TO START
;dly0		dex
;		bne	dly0

;		lda	#$02		;ENABLE FAST CLOCK (PHI2 to FCLK and CS0B-CS7B to FCLK)
;		tsb	SSCR		;tsb instruction so there is no glitch on FCLK Start

					;ALLOW TIME TO STABILIZE ON FCLOCK
;		ldx	#$400
;dly1     	dex
;		bne 	dly1
	ENDIF
	

        LDA   #^_BEG_DATA  ;get bank of data
        PHA
        PLB                ;set data bank register
        REP   #$20         ;back to 16 bit mode
        LONGA ON

****************************************************************
*                                                              *
*    Next, we want to copy the initialized data from           *
*      ROM to RAM.                                             *
*                                                              *
****************************************************************

        LDA   #_END_DATA-_BEG_DATA ;number of bytes to copy
        BEQ   SKIP         ;if none, just skip
        DEC   A            ;less one for MVN instruction
        LDX   #<_ROM_BEG_DATA ;get source into X
        LDY   #<_BEG_DATA  ;get dest into Y
        MVN   #^_ROM_BEG_DATA,#^_BEG_DATA ;copy bytes
SKIP:

****************************************************************
*                                                              *
*   Now, clear out the uninitialized data area.                *
*    We assume that it is in the same bank as DATA.            *
*                                                              *
****************************************************************

        LDX   #_END_UDATA-_BEG_UDATA  ;get number of bytes to clear
        BEQ   DONE         ;nothing to do
        LDA   #0           ;get a zero for storing
        SEP   #$20         ;do byte at a time
        LDY   #_BEG_UDATA  ;get beginning of zeros

LOOP    STA   |0,Y         ;clear memory
        INY                ;bump pointer
        DEX                ;decrement count
        BNE   LOOP         ;continue till done
        REP   #$20         ;16 bit memory reg
DONE:

****************************************************************
*                                                              *
*   Finally, transfer control to the real program.             *
*                                                              *
****************************************************************
;           Small   Model Function Calls use module Function_Name  and xdef __Function_Name
;           Medium  Model Function Calls use module Function_Name  and xdef ~_Function_Name
;           Large   Model Function Calls use module Function_Name  and xdef ~~Function_Name
;           Compact Model Function Calls use module Function_Name  and xdef _~Function_Name


	IF	SMALL
        XREF  __main      ;change MYSTART to yours
        JSR   >__main     ;long jump in case not bank 0

;	XDEF  ___exit
 ;___exit:
        BRK
	ELSEIF	MEDIUM
        XREF  ~_main      ;change MYSTART to yours
        JSL   ~_main     ;long jump in case not bank 0

;	XDEF ~__exit
;~__exit:
        BRK
	ELSEIF	COMPACT
        XREF  _~main      ;change MYSTART to yours
        JSR   _~main     ;long jump in case not bank 0

;	XDEF  _~_exit
;_~_exit:
        BRK
	ELSEIF	LARGE
        XREF  ~~main      ;change MYSTART to yours
        JSL   ~~main     ;long jump in case not bank 0

;	XDEF ~~_exit
;~~_exit:
        BRK
	ENDIF


        sttl "WDC_CStartup_816 IRQ - Interrupt Handler Code"
	.page

;***************************************************************
;                                                              *
;   Example of transfering control to the real Interrupt       *
;    Handler written in 'C'. Note: save all the registers      *
;                                                              *
;***************************************************************
		XDEF	IRQ
	IF	SMALL
		XREF	__IRQHandler
	ELSEIF	MEDIUM
		XREF	~_IRQHandler
	ELSEIF	COMPACT
		XREF	_~IRQHandler
	ELSEIF	LARGE
		XREF	~~IRQHandler
	ENDIF

IRQ:	
		LONGA	ON
		LONGI	ON
		rep	#$30
				;Example of needing to read/write to data in another data bank
	IF	SMALL
	ELSEIF	MEDIUM
		plb		; set data bank register to _DATA
		phd		; save Direct Page Register
	ELSEIF	COMPACT
	ELSEIF	LARGE
		phb		; save Data Bank
		phd		; save Direct Page Register
	ENDIF
		pha
		phx
		phy
	IF	SMALL
		jsr		__IRQHandler
	ELSEIF	MEDIUM
		jsl		~_IRQHandler
	ELSEIF	COMPACT
		jsr		_~IRQHandler
	ELSEIF	LARGE
		jsl		~~IRQHandler
	ENDIF
		ply
		plx
		pla
	IF	SMALL
	ELSEIF	MEDIUM
		pld		; restore Direct Page Reg
		plb		; Restore Data Bank
	ELSEIF	COMPACT
	ELSEIF	LARGE
		pld		; restore Direct Page Reg
		plb		; Restore Data Bank
	ENDIF
		RTI


;************************************************
; Bad Vectors
;************************************************

Undefined_IRQ:
		nop
		bra Undefined_IRQ

        XREF  _BEG_DATA
        XREF  _END_DATA
        XREF  _ROM_BEG_DATA
        XREF  _BEG_UDATA
        XREF  _END_UDATA


	ends

        sttl "WDC_CStartup_816 Shadow Vector Defines"
	.page

;***************************************************************************
;        $7E00 - $7FFF New Expanded Shadow Vector Section Definitions
;***************************************************************************
;***************************************************************************
;***************************************************************************


shadow_vectors:	section		; the real reset and interrupt vectors used by WDCMON.ASM
	IF	USING_265
					;65C265 Vectors
					;Status bit E = 0 (Native mode)
		org     $7E80		;Native Mode Vectors! (16 bit mode)

		dw	Undefined_IRQ	; $FF80 - IRQT0(265) - Timer #0
		dw	Undefined_IRQ	; $FF82 - IRQT1(265) - Timer #1
		dw	Undefined_IRQ	; $FF84 - IRQT2(265) - Timer #2
		dw	Undefined_IRQ	; $FF86 - IRQT3(265) - Timer #3
		dw	Undefined_IRQ	; $FF88 - IRQT4(265) - Timer #4
		dw	Undefined_IRQ	; $FF8A - IRQT5(265) - Timer #5
		dw	Undefined_IRQ	; $FF8C - IRQT6(265) - Timer #6
		dw	Undefined_IRQ	; $FF8E - IRQT7(265) - Timer #7
		dw	Undefined_IRQ	; $FF90 - IRQPE56(265)
		dw	Undefined_IRQ	; $FF92 - IRQNE57(265)
		dw	Undefined_IRQ	; $FF94 - IRQPE60(265)
		dw	Undefined_IRQ	; $FF96 - IRQPE62(265)
		dw	Undefined_IRQ	; $FF98 - IRQNE64(265)
		dw	Undefined_IRQ	; $FF9A - IRQNE66(265)
		dw	Undefined_IRQ	; $FF9C - IRQPIB(265)
		dw	IRQ		; $FF9E - IRQ(265)
		dw	Undefined_IRQ	; $FFA0 - IRQAR0(265) - Uart #0 Receive IRQ
		dw	Undefined_IRQ	; $FFA2 - IRQAT0(265) - Uart #0 Transmit IRQ
		dw	Undefined_IRQ	; $FFA4 - IRQAR1(265) - Uart #1 Receive IRQ
		dw	Undefined_IRQ	; $FFA6 - IRQAT1(265) - Uart #1 Transmit IRQ
		dw	Undefined_IRQ	; $FFA8 - IRQAR1(265) - Uart #2 Receive IRQ
		dw	Undefined_IRQ	; $FFAA - IRQAT1(265) - Uart #2 Transmit IRQ
		dw	Undefined_IRQ	; $FFAC - IRQAR1(265) - Uart #3 Receive IRQ
		dw	Undefined_IRQ	; $FFAE - IRQAT1(265) - Uart #3 Transmit IRQ
		dw	Undefined_IRQ	; $FFB0 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFB2 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFB4 - IRQCOP(265)
		dw	Undefined_IRQ	; $FFB6 - IRQBRK(265)
		dw	Undefined_IRQ	; $FFB8 - ABORT(265)
		dw	Undefined_IRQ	; $FFBA - NMI(265)
		dw	Undefined_IRQ	; $FFBC - IRQRVD(265)
		dw	Undefined_IRQ	; $FFBE - IRQRVD(265)

					;Status bit E = 1 (Emulation mode)
					;Emulation Mode Vectors!

		dw	Undefined_IRQ	; $FFC0 - IRQT0(265) - Timer #0
		dw	Undefined_IRQ	; $FFC2 - IRQT1(265) - Timer #1
		dw	Undefined_IRQ	; $FFC4 - IRQT2(265) - Timer #2
		dw	Undefined_IRQ	; $FFC6 - IRQT3(265) - Timer #3
		dw	Undefined_IRQ	; $FFC8 - IRQT4(265) - Timer #4
		dw	Undefined_IRQ	; $FFCA - IRQT5(265) - Timer #5
		dw	Undefined_IRQ	; $FFCC - IRQT6(265) - Timer #6
		dw	Undefined_IRQ	; $FFCE - IRQT7(265) - Timer #7
		dw	Undefined_IRQ	; $FFD0 - IRQPE56(265)
		dw	Undefined_IRQ	; $FFD2 - IRQNE57(265)
		dw	Undefined_IRQ	; $FFD4 - IRQPE60(265)
		dw	Undefined_IRQ	; $FFD6 - IRQPE62(265)
		dw	Undefined_IRQ	; $FFD8 - IRQNE64(265)
		dw	Undefined_IRQ	; $FFDA - IRQNE66(265)
		dw	Undefined_IRQ	; $FFDC - IRQPIB(265)
		dw      Undefined_IRQ	; $FFDE - IRQ(265)
		dw	Undefined_IRQ	; $FFE0 - IRQAR0(265) - Uart #0 Receive IRQ ($FFE0)
		dw	Undefined_IRQ	; $FFE2 - IRQAT0(265) - Uart #0 Transmit IRQ ($FFE2)
		dw	Undefined_IRQ	; $FFE4 - IRQAR1(265) - Uart #1 Receive IRQ
		dw	Undefined_IRQ	; $FFE6 - IRQAT1(265) - Uart #1 Transmit IRQ
		dw	Undefined_IRQ	; $FFE8 - IRQAR1(265) - Uart #2 Receive IRQ
		dw	Undefined_IRQ	; $FFEA - IRQAT1(265) - Uart #2 Transmit IRQ
		dw	Undefined_IRQ	; $FFEC - IRQAR1(265) - Uart #3 Receive IRQ
		dw	Undefined_IRQ	; $FFEE - IRQAT1(265) - Uart #3 Transmit IRQ
		dw	Undefined_IRQ	; $FFF0 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF2 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF4 - IRQCOP(265)
		dw	Undefined_IRQ	; $FFF6 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF8 - ABORT(265)

					; Common Vectors for all CPUs
		dw	Undefined_IRQ	; $FFFA -  NMIRQ (ALL)
		dw	START		; $FFFC -  RESET (ALL)
		dw	Undefined_IRQ	; $FFFE -  IRQBRK (ALL)
        ELSEIF USING_816
					;65C816 Vectors
		org	$7EE4
					;Status bit E = 0 (Native mode)
		dw	Undefined_IRQ	; $FFE4 - COP(816)
		dw	Undefined_IRQ	; $FFE6 - BRK(816)
		dw	Undefined_IRQ	; $FFE8 - ABORT(816)
		dw	Undefined_IRQ	; $FFEA - NMI(816)
		dw	Undefined_IRQ	; $FFEC - IRQRVD(816)
		dw	IRQ		; $FFEE - IRQ(816)
					;Status bit E = 1 (Emulation mode)
		dw	Undefined_IRQ	; $FFF0 - IRQRVD(816)
		dw	Undefined_IRQ	; $FFF2 - IRQRVD(816)
		dw	Undefined_IRQ	; $FFF4 - COP(816Emulation)
		dw	Undefined_IRQ	; $FFF6 - IRQRVD(816Emulation)
		dw	Undefined_IRQ	; $FFF8 - ABORT(816Emulation)

					; Common Vectors for all CPUs
		dw	Undefined_IRQ	; $FFFA -  NMIRQ (ALL)
		dw	START		; $FFFC -  RESET (ALL)
		dw	Undefined_IRQ	; $FFFE -  IRQBRK (ALL)
	ENDIF

        sttl "WDC_CStartup_816 Vector Defines"
	.page


****************************************************************
*                                                              *
*   This section defines the interrupt and reset vectors.      *
*      The reset vectors always start at FFE4 in bank 0.       *
*      Since the vectors are only 16 bits, they must point     *
*      into bank 0. Replace the "Undefined_IRQ" with any       *
*      routines that handle that interrupt.                    *
*                                                              *
****************************************************************


	vectors:	section		; the real reset and interrupt vectors
	IF	USING_265
					;65C265 Vectors
					;Status bit E = 0 (Native mode)
		org     $FF80		;Native Mode Vectors! (16 bit mode)

		dw	Undefined_IRQ	; $FF80 - IRQT0(265) - Timer #0
		dw	Undefined_IRQ	; $FF82 - IRQT1(265) - Timer #1
		dw	Undefined_IRQ	; $FF84 - IRQT2(265) - Timer #2
		dw	Undefined_IRQ	; $FF86 - IRQT3(265) - Timer #3
		dw	Undefined_IRQ	; $FF88 - IRQT4(265) - Timer #4
		dw	Undefined_IRQ	; $FF8A - IRQT5(265) - Timer #5
		dw	Undefined_IRQ	; $FF8C - IRQT6(265) - Timer #6
		dw	Undefined_IRQ	; $FF8E - IRQT7(265) - Timer #7
		dw	Undefined_IRQ	; $FF90 - IRQPE56(265)
		dw	Undefined_IRQ	; $FF92 - IRQNE57(265)
		dw	Undefined_IRQ	; $FF94 - IRQPE60(265)
		dw	Undefined_IRQ	; $FF96 - IRQPE62(265)
		dw	Undefined_IRQ	; $FF98 - IRQNE64(265)
		dw	Undefined_IRQ	; $FF9A - IRQNE66(265)
		dw	Undefined_IRQ	; $FF9C - IRQPIB(265)
		dw	IRQ		; $FF9E - IRQ(265)
		dw	Undefined_IRQ	; $FFA0 - IRQAR0(265) - Uart #0 Receive IRQ
		dw	Undefined_IRQ	; $FFA2 - IRQAT0(265) - Uart #0 Transmit IRQ
		dw	Undefined_IRQ	; $FFA4 - IRQAR1(265) - Uart #1 Receive IRQ
		dw	Undefined_IRQ	; $FFA6 - IRQAT1(265) - Uart #1 Transmit IRQ
		dw	Undefined_IRQ	; $FFA8 - IRQAR1(265) - Uart #2 Receive IRQ
		dw	Undefined_IRQ	; $FFAA - IRQAT1(265) - Uart #2 Transmit IRQ
		dw	Undefined_IRQ	; $FFAC - IRQAR1(265) - Uart #3 Receive IRQ
		dw	Undefined_IRQ	; $FFAE - IRQAT1(265) - Uart #3 Transmit IRQ
		dw	Undefined_IRQ	; $FFB0 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFB2 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFB4 - IRQCOP(265)
		dw	Undefined_IRQ	; $FFB6 - IRQBRK(265)
		dw	Undefined_IRQ	; $FFB8 - ABORT(265)
		dw	Undefined_IRQ	; $FFBA - NMI(265)
		dw	Undefined_IRQ	; $FFBC - IRQRVD(265)
		dw	Undefined_IRQ	; $FFBE - IRQRVD(265)

					;Status bit E = 1 (Emulation mode)
					;Emulation Mode Vectors!

		dw	Undefined_IRQ	; $FFC0 - IRQT0(265) - Timer #0
		dw	Undefined_IRQ	; $FFC2 - IRQT1(265) - Timer #1
		dw	Undefined_IRQ	; $FFC4 - IRQT2(265) - Timer #2
		dw	Undefined_IRQ	; $FFC6 - IRQT3(265) - Timer #3
		dw	Undefined_IRQ	; $FFC8 - IRQT4(265) - Timer #4
		dw	Undefined_IRQ	; $FFCA - IRQT5(265) - Timer #5
		dw	Undefined_IRQ	; $FFCC - IRQT6(265) - Timer #6
		dw	Undefined_IRQ	; $FFCE - IRQT7(265) - Timer #7
		dw	Undefined_IRQ	; $FFD0 - IRQPE56(265)
		dw	Undefined_IRQ	; $FFD2 - IRQNE57(265)
		dw	Undefined_IRQ	; $FFD4 - IRQPE60(265)
		dw	Undefined_IRQ	; $FFD6 - IRQPE62(265)
		dw	Undefined_IRQ	; $FFD8 - IRQNE64(265)
		dw	Undefined_IRQ	; $FFDA - IRQNE66(265)
		dw	Undefined_IRQ	; $FFDC - IRQPIB(265)
		dw      Undefined_IRQ	; $FFDE - IRQ(265)
		dw	Undefined_IRQ	; $FFE0 - IRQAR0(265) - Uart #0 Receive IRQ ($FFE0)
		dw	Undefined_IRQ	; $FFE2 - IRQAT0(265) - Uart #0 Transmit IRQ ($FFE2)
		dw	Undefined_IRQ	; $FFE4 - IRQAR1(265) - Uart #1 Receive IRQ
		dw	Undefined_IRQ	; $FFE6 - IRQAT1(265) - Uart #1 Transmit IRQ
		dw	Undefined_IRQ	; $FFE8 - IRQAR1(265) - Uart #2 Receive IRQ
		dw	Undefined_IRQ	; $FFEA - IRQAT1(265) - Uart #2 Transmit IRQ
		dw	Undefined_IRQ	; $FFEC - IRQAR1(265) - Uart #3 Receive IRQ
		dw	Undefined_IRQ	; $FFEE - IRQAT1(265) - Uart #3 Transmit IRQ
		dw	Undefined_IRQ	; $FFF0 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF2 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF4 - IRQCOP(265)
		dw	Undefined_IRQ	; $FFF6 - IRQRVD(265)
		dw	Undefined_IRQ	; $FFF8 - ABORT(265)

					; Common Vectors for all CPUs
		dw	Undefined_IRQ	; $FFFA -  NMIRQ (ALL)
		dw	START		; $FFFC -  RESET (ALL)
		dw	Undefined_IRQ	; $FFFE -  IRQBRK (ALL)
        ELSEIF USING_816
					;65C816 Vectors
		org	$ffe4
					;Status bit E = 0 (Native mode)
		dw	Undefined_IRQ	; $FFE4 - COP(816)
		dw	Undefined_IRQ	; $FFE6 - BRK(816)
		dw	Undefined_IRQ	; $FFE8 - ABORT(816)
		dw	Undefined_IRQ	; $FFEA - NMI(816)
		dw	Undefined_IRQ	; $FFEC - IRQRVD(816)
		dw	IRQ		; $FFEE - IRQ(816)
					;Status bit E = 1 (Emulation mode)
		dw	Undefined_IRQ	; $FFF0 - IRQRVD(816)
		dw	Undefined_IRQ	; $FFF2 - IRQRVD(816)
		dw	Undefined_IRQ	; $FFF4 - COP(816Emulation)
		dw	Undefined_IRQ	; $FFF6 - IRQRVD(816Emulation)
		dw	Undefined_IRQ	; $FFF8 - ABORT(816Emulation)

					; Common Vectors for all CPUs
		dw	Undefined_IRQ	; $FFFA -  NMIRQ (ALL)
		dw	START		; $FFFC -  RESET (ALL)
		dw	Undefined_IRQ	; $FFFE -  IRQBRK (ALL)
	ENDIF

		ends


	        end

;**********************************************************************
;	End of WDC_CSTARTUP_C.ASM
;**********************************************************************

