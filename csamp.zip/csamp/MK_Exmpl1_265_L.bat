REM 'C' 65c265 Example #1 Program for the Large Model
REM File: MK_Exmpl1265_L.bat
REM 10/06/2003


del WDC_CStartup_816.obj
del WDC_CStartup_816.lst
del WDC_CStartup_816.sym
del exmpl1.obj
del exmpl1.lst
del exmpl1.sym
del exmpl1.map
del *.opt
del *.tmp
WDC816AS -g -l -DUSING_265 -DLARGE WDC_CStartup_816
WDC816CC -lt -ml -bs -DUSING_265 exmpl1
WDCLN -c1000 -sz -hz -g -t -o exmpl1.bin WDC_CStartup_816.obj exmpl1.obj -lcl
WDCSYM exmpl1 > symbols_265L.txt
WDCOBJ exmpl1 > objects_265L.txt
REM ALL Done!
pause