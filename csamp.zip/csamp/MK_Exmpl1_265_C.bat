REM 'C' 65c265 Example #1 Program for the Compact Model
REM File: MK_Exmpl1_265_C.bat
REM 10/07/2003

del WDC_CStartup_816.obj
del WDC_CStartup_816.lst
del WDC_CStartup_816.sym
del exmpl1.obj
del exmpl1.lst
del exmpl1.sym
del exmpl1.map
del *.opt
del *.tmp
WDC816AS -g -l -DUSING_265 -DCOMPACT WDC_CStartup_816
WDC816CC -lt -mc -bs -sop -DUSING_265 exmpl1
WDCLN -c1000 -sz -hz -g -t -o exmpl1.bin WDC_CStartup_816.obj exmpl1.obj -lcc
WDCSYM -A -L exmpl1.sym>symbols_265C.txt
WDCOBJ exmpl1>objects_265C.txt
REM ALL Done!
pause