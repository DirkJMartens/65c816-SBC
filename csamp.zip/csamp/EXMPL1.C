// File: EXMPL1.C
// 01/07/2003

//
//  EXMPL1 - ZIO-1 daughter board and DLL test program
//
//	by Jim Goodnow II - Zardoz Software, Inc. - 3/11/1997
//


//pargma TITLE
//pargma STTL

#if USING_134
#elif USING_265
#elif USING_816
#elif USING_02
#else
#asm
		EXIT         "Not Valid Processor: Use -DUSING_816, etc. ! ! ! ! ! ! ! ! ! ! ! !"
#endasm
#endif



#if USING_134
#asm
			title  "WDC65C134 'C' Compiler Example of LED bars moving - examp1.asm"
			sttl
#endasm
#elif USING_265
#asm
			title  "WDC65C265 'C' Compiler Example of LED bars moving - examp1.asm"
			sttl
#endasm
#elif USING_816
#asm
			title  "WDC65C816 'C' Compiler Example of LED bars moving - examp1.asm"
			sttl
#endasm
#elif USING_02
#asm
			title  "WDC65C02 'C' Compiler Example of LED bars moving - examp1.asm"
			sttl
#endasm
#endif


// ****************************************************************************
// ****************************************************************************
// End of testing for proper Command line Options for Compiling of this program
// ****************************************************************************
// ****************************************************************************


/* BEGIN_FILE_HDR
********************************************************************************
                               E X M P L 1 . C
********************************************************************************
********************************************************************************
* FILE NAME: EXMPL1.c
*
* TITLE: 'C' EXAMPLE
*
*  DATA_RIGHTS: Western Design Center and R & C Services Proprietary
*               Copyright(C) 1980-2003
*               All rights reserved. Reproduction in any manner, 
*               in whole or in part, is strictly prohibited without
*               the prior written approval of R & C Services or 
*               Western Design Center.
*
* DESCRIPTION:
*     This is a sample code to show how to initialize the VIA
*      
*      
*
*
* DEFINED FUNCTIONS:
*     msdelay()
*        - Delay
*     IRQHandler()
*        - VIA Timer Interrupt Handler
*     check_endof_memory()
*        - 
*
* SPECIAL CONSIDERATIONS:
*      Note: Use // as a comment so that we can comment out blocks by using 'slash'* *'slash'
*     
*
* AUTHOR: R. Greenthal
*
* CREATION DATE: Oct 08,2003
*
* REVISION HISTORY
*     Name           Date       Description
*     ------------   ---------  ------------------------------------------------
*     R. Greenthal   10/08/2003 Initial
*
********************************************************************************
 END_FILE_HDR */

/*
 *============================= DEFINITION INCLUDES ============================
 *           ( listing of all header files having data types, and con-
 *             stants, but no function prototypes used by this module )
 */
   /* <None> */


/*
 *============================ FUNCTION INCLUDES ===============================
 *     ( listing of all header files having prototypes, data types, and
 *       constants used by this module. In addition, list all the func-
 *       tions used by this module below the appropriate header file. )
 */


// define some unsigned types

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;


void IRQHandler( void );
static void msdelay( ushort ms );


extern void START( void );


/*
 *================================= INPUTS =====================================
 *   (listing of all global variables "read" but not modified by this module)
 */
   /* <None> */



/*
 *================================= OUTPUTS ====================================
 *   (listing of all global variables "modified" but not read by this module)
 */

   /* <None> */


/*
 *================================= UPDATES ====================================
 *   (listing of all global variables "read" and "modified" by this module)
 */

int delay = 10;


/*
 *======================= PRIVATE CONSTANTS and MACROS =========================
 *       (listings of all constants and macros used by this module)
 */



// this is the clock rate on the board

#define	CLK_RATE	8000000		; 8 MHZ

// these are the addresses of the W65C22S part
// note that the 'volatile' declaration forces the compiler to use
// a single byte read instead of the more efficient two byte read

#if USING_134
			//***************************
			// 65C134 Specific Registers
			//***************************
#define C134_IFR2	*( volatile uchar * )0x0008
#define C134_IER2	*( volatile uchar * )0x0009

			//***************************
			// VIA Specific Registers
			//***************************
#define	VIA_ORB		*( volatile uchar * )0x0030
#define	VIA_IRB		*( volatile uchar * )0x0030
#define	VIA_ORA		*( volatile uchar * )0x0031
#define	VIA_IRA		*( volatile uchar * )0x0031
#define	VIA_DDRB	*( volatile uchar * )0x0032
#define	VIA_DDRA	*( volatile uchar * )0x0033
#define	VIA_T1CLO	*( volatile uchar * )0x0034
#define	VIA_T1CHI	*( volatile uchar * )0x0035
#define	VIA_T1LLO	*( volatile uchar * )0x0036
#define	VIA_T1LHI	*( volatile uchar * )0x0037
#define	VIA_T2CLO	*( volatile uchar * )0x0038
#define	VIA_T2CHI	*( volatile uchar * )0x0039
#define	VIA_SR		*( volatile uchar * )0x003a
#define	VIA_ACR		*( volatile uchar * )0x003b
#define	VIA_PCR		*( volatile uchar * )0x003c
#define	VIA_IFR		*( volatile uchar * )0x003d
#define	VIA_IER		*( volatile uchar * )0x003e
#define	VIA_ORANH	*( volatile uchar * )0x003f
#define	VIA_IRANH	*( volatile uchar * )0x003f

#elif USING_265
			//***************************
			// 65C265 Specific Registers
			//***************************
#define	C265_EIFR	*( volatile uchar * )0xdf45
#define	C265_EIER 	*( volatile uchar * )0xdf47


			//***************************
			// VIA Specific Registers
			//***************************
#define	VIA_ORB		*( volatile uchar * )0xDF00
#define	VIA_IRB		*( volatile uchar * )0xDF00
#define	VIA_ORA		*( volatile uchar * )0xDF01
#define	VIA_IRA		*( volatile uchar * )0xDF01
#define	VIA_DDRB	*( volatile uchar * )0xDF02
#define	VIA_DDRA	*( volatile uchar * )0xDF03
#define	VIA_T1CLO	*( volatile uchar * )0xDF04
#define	VIA_T1CHI	*( volatile uchar * )0xDF05
#define	VIA_T1LLO	*( volatile uchar * )0xDF06
#define	VIA_T1LHI	*( volatile uchar * )0xDF07
#define	VIA_T2CLO	*( volatile uchar * )0xDF08
#define	VIA_T2CHI	*( volatile uchar * )0xDF09
#define	VIA_SR		*( volatile uchar * )0xDF0A
#define	VIA_ACR		*( volatile uchar * )0xDF0B
#define	VIA_PCR		*( volatile uchar * )0xDF0C
#define	VIA_IFR		*( volatile uchar * )0xDF0D
#define	VIA_IER		*( volatile uchar * )0xDF0E
#define	VIA_ORANH	*( volatile uchar * )0xDF0F
#define	VIA_IRANH	*( volatile uchar * )0xDF0F

#else

#define	VIA_ORB		*( volatile uchar * )0xf0
#define	VIA_IRB		*( volatile uchar * )0xf0
#define	VIA_ORA		*( volatile uchar * )0xf1
#define	VIA_IRA		*( volatile uchar * )0xf1
#define	VIA_DDRB	*( volatile uchar * )0xf2
#define	VIA_DDRA	*( volatile uchar * )0xf3
#define	VIA_T1CLO	*( volatile uchar * )0xf4
#define	VIA_T1CHI	*( volatile uchar * )0xf5
#define	VIA_T1LLO	*( volatile uchar * )0xf6
#define	VIA_T1LHI	*( volatile uchar * )0xf7
#define	VIA_T2CLO	*( volatile uchar * )0xf8
#define	VIA_T2CHI	*( volatile uchar * )0xf9
#define	VIA_SR		*( volatile uchar * )0xfa
#define	VIA_ACR		*( volatile uchar * )0xfb
#define	VIA_PCR		*( volatile uchar * )0xfc
#define	VIA_IFR		*( volatile uchar * )0xfd
#define	VIA_IER		*( volatile uchar * )0xfe
#define	VIA_ORANH	*( volatile uchar * )0xff
#define	VIA_IRANH	*( volatile uchar * )0xff
#endif



// ********************************************************************
//                       M A I N   P R O G R A M
// ********************************************************************

void main( void )
{
	ushort	x;
	ushort	t;
	float	fp_test;


// first, we initialize the VIA chip registers

	VIA_ORB  = 0xFF;			// start by turning all segments off
	VIA_DDRB = 0xFF;			// all outputs
	VIA_IER  = 0xC0;			// enable timer 1 interrupt
	VIA_ACR  = 0x40;			// continuous interrupt, square wave

// now, set the timeout time. If we are simulating, the RESET vector
// points to our real start address. If we are running with the
// evaluation board, the RESET vector points to the EPROM address.
// we use this information to change the delay, since the simulator
// runs slower than the evaluation board.

	VIA_T1CLO = 0xFF;
//	if ( *( ushort * )0xfffc == ( ushort )( long )( void * )START )
	if ( *( ushort * )0xfffc == ( ushort )( long )START )
		VIA_T1CHI = 0x40;
	else
		VIA_T1CHI = 0xFF;

// so we enable interrupts and away we go
// while we are waiting for a timer to timeout, we check the CB1 and
//  CB2 input bits in the IFR to see if they have been triggered.
// if one has, it causes the global delay variable to increment or
// decrement which changes the speed of the display.

#if USING_134
	C134_IER2 = 0x80;	// Enable IRQ for the 65C134
#elif USING_265
	C265_EIER = 0x80;	// Enable IRQ for the 65C265
#endif


#if USING_134
				//Dummy operations to test the Floating point RAM in PAGE0
//#include "math.h"
//	fp_test = sin(2);
//	fp_test = 3.14;
//	fp_test *= 2;
#endif


	asm { cli; }		// Enable IRQ's for the processor

	for ( ;; ) {
		x = VIA_IFR;
		if ( x & 0x08 ) {
			if ( delay > 0 )
				delay--;
		}
		else if ( x & 0x10 ) {
			if ( delay < 20 )
				delay++;
		}
		else
			continue;
		msdelay( 200 );		// debounce by waiting for 200 ms
		VIA_IFR = 0x18;		// now, clear the flag
	}  // End of for ( ;; )
}  // End of Main() 



//***********************************************
//  Functions
//***********************************************

static uchar	bits = 0x01;		// byte containing current LED state
static uchar	cnt;			// counter used to count for delay

void IRQHandler( void )
{
//	uchar	x;
	register uchar	x;

	if ( VIA_IFR & 0x40 ) {
		if ( ++cnt >= delay ) {
			VIA_ORB = ~bits;
			bits <<= 1;
			if ( bits == 0x40 )
				bits = 0x01;
			cnt = 0;
		}
		x = VIA_T1CLO;		// clear VIA IFR bit by doing a dummy read
#if USING_134
		C134_IFR2 |= 0x80;		// clear IFR2 IRQ bit
#elif USING_265
		C265_EIFR |= 0x80;		// clear EIFR IRQ bit
#endif
	}  // End of if ( VIA_IFR & 0x40)
}  // End of Function IRQHandler() 




//
// this routine waits the specified number of milliseconds.

static void msdelay( ushort ms )
{
	ulong	ticks;
	ushort	wraps;
	ushort	rem;

// calculate the number of ticks needed
//	ticks = ( CLK_RATE / 1000 ) * ( ulong )ms;	//WARNING: ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	ticks = ( 8000000 / 1000 ) * ( ulong )ms;

// so given that many ticks, how many times must the timer wrap before done
	wraps = ticks / 0x10000;

// before we start wrapping, if we have any extra cycles, spend them
	rem = ticks % 0x10000;
	VIA_T2CLO = rem;
	VIA_T2CHI = rem >> 8;

// now, we loop waiting for the timer to expire and each time it does,
// we decrement 'wraps' till all done.
	do {
		if ( ( VIA_IFR & 0x20 ) != 0 ) {
			wraps--;
			VIA_T2CHI = 0xff;
		}
	} while( wraps != 0xffff );
}  // End of Function msdelay() 




void check_endof_memory(void)
{
#asm

This_project_end:
WDCMON_RAM_START	EQU	$7C00
;ROMSPACE EQU WDCMON_RAM_START-This_project_end  ;gives space left in the ROM BEFORE WDCMON TABLES
;	IF ROMSPACE<0
;		EXIT         "Not Enough Memory for This Application - bumping into WDCMON! ! ! ! ! ! ! ! ! ! ! !"
;	ENDIF

#endasm
}  // End of Function check_endof_memory() 


/******************************************************
                 End of EXMPL1.C
*******************************************************/

