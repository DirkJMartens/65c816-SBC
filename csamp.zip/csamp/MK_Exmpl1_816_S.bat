REM 'C' 65c816 Example #1 Program for the Small thru Large Model
REM File: MKWDCStartup816.bat
REM 11/10/2003

del WDC_CStartup_816.obj
del WDC_CStartup_816.lst
del WDC_CStartup_816.sym
del exmpl1.obj
del exmpl1.lst
del exmpl1.sym
del *.opt
del *.tmp

WDC816AS -g -l t0s
WDC816AS -g -l -DUSING_816 -DSMALL WDC_CStartup_816
WDC816CC -lt -ms -bs -DUSING_816 exmpl1.c
WDCLN -c1000 -sz -hz -g -t -o exmpl1.bin WDC_CStartup_816.obj exmpl1.obj -lcs
REM WDCLN -c1000 -sz -hz -g -t -o exmpl1.bin t0s.obj exmpl1.obj -lcs
WDCSYM exmpl1 > symbols_816S.txt
WDCOBJ exmpl1 > objects_816S.txt
REM ALL Done!
pause