;File: WDC_Cstartup_02.asm
; 10/07/2003


     PW 128         ;Page Width (# of char/line) 
     PL 60          ;Page Length for HP Laser
     INCLIST ON     ;Add Include files in Listing

				;*********************************************
				;Test for Valid Processor defined in -D option
				;*********************************************
	IF	USING_02
	ELSEIF	USING_134
	ELSE
		EXIT         "Not Valid Processor: Use -DUSING_02 or -DUSING_134! ! ! ! ! ! ! ! ! ! ! !"
	ENDIF



;****************************************************************************
;****************************************************************************
; End of testing for proper Command line Options for Assembly of this program
;****************************************************************************
;****************************************************************************

	IF	USING_134
			title  "WDC65C134 'C' Compiler Startup Initialization V 1.00 - WDC_Cstartup_02.asm"
			sttl 
	ELSEIF	USING_02
			title  "WDC65C02 'C' Compiler Startup Initialization V 1.00- WDC_Cstartup_02.asm"
			sttl 
	ENDIF


; bgnpkhdr
;***************************************************************************
;  FILE_NAME: WDC_Cstartup_02.asm
;
;  DATA_RIGHTS: Western Design Center and R & C Services Proprietary
;               Copyright(C) 1980-2003
;               All rights reserved. Reproduction in any manner, 
;               in whole or in part, is strictly prohibited without
;               the prior written approval of R & C Services or 
;               Western Design Center.
;
;               Information contained in this publication regarding
;               device applications and the like is intended through
;               suggestion only and may be superseded by updates.  
;               It is your responsibility to ensure that your application
;               meets with your specifications.  No representation or
;               warranty is given and no liability is assumed by 
;               Western Design Center, Inc. with respect to the accuracy
;               or use of such information, or infringement of patents
;               or other intellectual property rights arising from such
;               use or otherwise.  Use of Western Design Center's products
;               as critical components in life support systems is not
;               authorized except with express written approval by
;               Western Design Center, Inc.'s.  No licenses are conveyed,
;               implicitly or otherwise, under any intellectual property rights.
;
;
;
;  TITLE: WDC_Cstartup_02.ASM
;
;  DESCRIPTION: This File describes the WDC SDS Startup Initialization for the 'C' Compiler.
;                This is for both the W65c02 and the W65c134
;
;                Program Flow
;
;                First we make sure we are in native mode.
;                Then we set up the stack pointer.
;                Then we set the data bank register.
;                Then we copy the initialized data.
;                Then we clear out the uninitialized data.
;                Then we call main.
;
;  DEFINED FUNCTIONS:
;          Undefined_IRQ
;                   - Process a Bad Interrupt Vector - send code & Hang!
;
;
;  SPECIAL_CONSIDERATIONS:
;
;
;  SHARED_DATA:
;          None
;
;  GLOBAL_MODULES:
;          None
;
;  LOCAL_MODULES:
;          See above in "DEFINED FUNCTIONS"
;
;  AUTHOR: Jim Goodnow II
;
;  CREATION DATE: March 11,1997
;
;  REVISION HISTORY
;     Name           Date         Description
;     ------------   ----------   ------------------------------------------------
;     R. Greenthal   10/07/2003   1.01 Initial
;
;
;
; NOTE:
;    Change the lines for each version - current version is 1.00

;
;
;***************************************************************************
;endpkhdr


;***************************************************************************
;                             Include Files
;***************************************************************************

	include	"zpage.inc"


;***************************************************************************
;                              Global Modules
;***************************************************************************
;None

;***************************************************************************
;                              External Modules
;***************************************************************************
;None

;***************************************************************************
;                              External Variables
;***************************************************************************
;None


;***************************************************************************
;                               Local Constants
;***************************************************************************
;


WDCMON_RAM_START	EQU	$00:7D00


	IF	USING_134
						;************************************************
						; Internal I/O Registers and ports for the 65C134
						;************************************************
PCS3:			equ	$07		;Chip Select Enable Register
IFR2:           	equ     $08		;Interrupt Flag Register #2
IER2:           	equ     $09		;Interrupt Enable Register #2
TCR1:           	equ     $0a		;Timer Control Register #1
TCR2:           	equ     $0b		;Timer Control Register #2
SIB:			equ	$14		;Serial Interface Bus
SCSR:			equ	$19		;SIB Control and Status Reg
BCR:			equ	$1b		;Bus Control Register
ACSR:			equ	$22		;Async Control and Status Reg
IFR1:           	equ     $2C		;Interrupt Flag Register #1
IER1:           	equ     $2D		;Interrupt Enable Register #1
	ENDIF


	****************************************************************
	*                                                              *
	*   Define a special section in case most of the               *
	*      code is not in bank 0.                                  *
	*                                                              *
	****************************************************************

MCH_STACK	EQU	$FF 

C_STACK		EQU	$7CFF

	.page

;***************************************************************************
;                          RAM Section
;***************************************************************************
;   


	
	sttl "WDC_CStartup_02 Code"
	.page
;***************************************************************************
;***************************************************************************
;                    WDC_CStartup_02 Code Section
;***************************************************************************
;***************************************************************************


	chip	65C02


STARTUP	SECTION	OFFSET $7D40

	xref  _BEG_DATA
	xref  _END_DATA
	xref  _ROM_BEG_DATA
	xref  _BEG_UDATA
	xref  _END_UDATA

	xdef	_START

;	CODE

_START:
START:
				;*************************************************
	sei			;Disable IRQ's until User/Application does a "cli"
				;*************************************************
	IF	USING_134		Special Code for 134 Startup ***********
;		lda     #$40            ; enable CS6B
;		tsb     PCS3            ; enable external RAM
;		lda     #$C1            ; Enable IRQ1, IRQ2, NMI, Non emulation/TRACE on
;		sta     BCR
;		lda     #$80            ; enable IRQ2 flag
;		tsb     IER2

					;********
					;WARNING:
					;********
					; TCR1 Powers up as $00
					; This means the FCLK is Stopped!
					; and PHI2 is CLK (32 KHZ)

					;Added Code 08/05/2002
					;START FAST CLOCK BUT NOT USING YET
;		lda	#$04
;		tsb 	TCR1
					;Delay for Fast Clock to come up to speed
;		ldx	#$00
;dly0     	nop
;	 	dex
;		bne 	dly0

;	 	lda	#$02		;ENABLE FAST CLOCK
;		tsb	TCR1
					;ALLOW TIME TO STABILIZE ON FCLOCK
;		ldx	#$00
;dly1     	nop
;	 	dex
;		bne 	dly1
	ENDIF

	cld			; clear decimal mode
	ldx	#MCH_STACK	; get the hardware stack address
	txs			; and set the stack to it


	lda	#<C_STACK	; get the software stack address
	sta	SP
	lda	#>C_STACK
	sta	SP+1

	****************************************************************
	*                                                              *
	*    Next, we want to copy the initialized data from           *
	*      ROM to RAM.                                             *
	*                                                              *
	****************************************************************

	lda	#<_END_DATA-_BEG_DATA	;number of bytes to copy
	sta	R0
	lda	#>_END_DATA-_BEG_DATA
	sta	R0+1
	ora	R0
	beq	copydone		; nothing to do
	lda	#<_ROM_BEG_DATA		; get source into R1
	sta	R1
	lda	#>_ROM_BEG_DATA
	sta	R1+1
	lda	#<_BEG_DATA		; get dest into R2
	sta	R2
	lda	#>_BEG_DATA
	sta	R2+1
	ldy	#0
copyloop:
	lda	(R1),Y
	sta	(R2),Y
	iny
	bne	copyskip
	inc	R1+1
	inc	R2+1
copyskip:
	lda	R0
	bne	copyskip2
	dec	R0+1
	bmi	copydone
copyskip2:
	dec	R0
	bra	copyloop
copydone:

	****************************************************************
	*                                                              *
	*   Now, clear out the uninitialized data area.                *
	*    We assume that it is in the same bank as DATA.            *
	*                                                              *
	****************************************************************

	lda	#<_END_UDATA-_BEG_UDATA  ;get number of bytes to clear
	sta	R0
	lda	#>_END_UDATA-_BEG_UDATA
	sta	R0+1
	ora	R0
	beq	done
	lda	#<_BEG_UDATA		; get beginning of zeroes
	sta	R1
	lda	#>_BEG_UDATA
	sta	R1+1
	lda	#0			;get a zero for storing
	tay
loop:
	tya
	sta	(R1),y			; clear memory
	inc	R1
	bne	skip
	inc	R1+1
skip:
	lda	R0
	bne	skip2
	dec	R0+1
	bmi	done
skip2:
	dec	R0
	bra	loop			;continue till done
done:
				;*************************************************
;	cli			;Enable IRQ's User/Application
				;*************************************************

	****************************************************************
	*                                                              *
	*   Finally, transfer control to the real program.             *
	*                                                              *
	****************************************************************

	xref	_main
	jsr	_main
	brk

	xdef	IRQ
	xref	_IRQHandler
IRQ:	
	pha		; save Hardware registers
	phx
	phy
	ldx	#19
1?:
	lda	R0,X	;Save 20 byte tmp register area (R0 - R4)(See zpage.inc)
	pha
	dex
	bpl	1?
	ldx	#8
2?:
	lda	VAL-1,X	;Save 8 byte Stack Register area
	pha		; (VAL, SP,AFRAME, FRAME, LFRAME, and PC)
	dex		;(See zpage.inc)
	bne	2?
	jsr	_IRQHandler
	ldx	#-8
3?:
	pla
	sta	VAL+8,X	;Restore 8 byte Stack Register area
	inx
	bne	3?
	ldx	#-20
4?:
	pla
	sta	R0+20,X	;Restore 20 byte tmp register area
	inx
	bne	4?
	ply
	plx
	pla
	rti


DUMMY_IRQ:
		nop
		bra	DUMMY_IRQ

WDCMON_START	EQU	$7E00
ROMSPACE EQU WDCMON_START-*  ;gives space left in the ROM BEFORE TABLES
	IF ROMSPACE<0
		EXIT         "Not Enough Memory for WDC_Cstartup_02.ASM - bumping into WDCMON! ! ! ! ! ! ! ! ! ! ! !"
	ENDIF

;        ENDS


	****************************************************************
	*                                                              *
	*   This section defines the interrupt and reset vectors.      *
	*      The reset vectors always start at FFFA. Replace the     *
	*      zeroes with any routines that handle interrupts.        *
	*                                                              *
	****************************************************************

	IF	USING_134
shadow_vectors	SECTION OFFSET $7ED0		;65C134 8 bit Interrupt Vectors

		dw	DUMMY_IRQ	; $FFD0 - PE44(134)
		dw	DUMMY_IRQ	; $FFD2 - PE45(134)
		dw	DUMMY_IRQ	; $FFD4 - NE46(134)
		dw	DUMMY_IRQ	; $FFD6 - NE47(134)
		dw	DUMMY_IRQ	; $FFD8 - PE50(134)
		dw	DUMMY_IRQ	; $FFDA - PE51(134)
		dw	DUMMY_IRQ	; $FFDC - NE52(134)
		dw	DUMMY_IRQ	; $FFDE - NE43(134)
		dw	DUMMY_IRQ	; $FFE0 - IRQRVD2(134)
		dw	DUMMY_IRQ	; $FFE2 - IRQRVD1(134)
		dw	DUMMY_IRQ	; $FFE4 - IRQAT(134)
		dw	DUMMY_IRQ	; $FFE6 - IRQAR(134)
		dw	DUMMY_IRQ	; $FFE8 - C134_SBI(134)
		dw	DUMMY_IRQ	; $FFEA - PE54(134)
		dw	DUMMY_IRQ	; $FFEC - PE55(134)
		dw	DUMMY_IRQ	; $FFEE - PE56(134)
		dw	DUMMY_IRQ	; $FFF0 - NE57(134)
		dw	DUMMY_IRQ	; $FFF2 - IRQT1(134)
		dw	DUMMY_IRQ	; $FFF4 - IRQT2(134)
		dw	IRQ		; $FFF6 - IRQ1(134)
		dw      IRQ	; $FFF8 - IRQ2(134)

					; Common 8 bit Vectors for all CPUs
		dw	DUMMY_IRQ	; $FFFA -  NMIRQ
		dw	START		; $FFFC -  RESET
		dw	IRQ		; $FFFE -  IRQ BRK

	ELSEIF	USING_02
shadow_vectors	SECTION OFFSET $7EFA
		dw	DUMMY_IRQ	; $FFFA -  NMIRQ
		dw	START		; $FFFC -  RESET
		dw	IRQ		; $FFFE -  IRQ BRK
	ENDIF
	ENDS





	IF	USING_134
VECTORS	SECTION OFFSET $FFD0		;65C134 8 bit Interrupt Vectors

		dw	DUMMY_IRQ	; $FFD0 - PE44(134)
		dw	DUMMY_IRQ	; $FFD2 - PE45(134)
		dw	DUMMY_IRQ	; $FFD4 - NE46(134)
		dw	DUMMY_IRQ	; $FFD6 - NE47(134)
		dw	DUMMY_IRQ	; $FFD8 - PE50(134)
		dw	DUMMY_IRQ	; $FFDA - PE51(134)
		dw	DUMMY_IRQ	; $FFDC - NE52(134)
		dw	DUMMY_IRQ	; $FFDE - NE43(134)
		dw	DUMMY_IRQ	; $FFE0 - IRQRVD2(134)
		dw	DUMMY_IRQ	; $FFE2 - IRQRVD1(134)
		dw	DUMMY_IRQ	; $FFE4 - IRQAT(134)
		dw	DUMMY_IRQ	; $FFE6 - IRQAR(134)
		dw	DUMMY_IRQ	; $FFE8 - C134_SBI(134)
		dw	DUMMY_IRQ	; $FFEA - PE54(134)
		dw	DUMMY_IRQ	; $FFEC - PE55(134)
		dw	DUMMY_IRQ	; $FFEE - PE56(134)
		dw	DUMMY_IRQ	; $FFF0 - NE57(134)
		dw	DUMMY_IRQ	; $FFF2 - IRQT1(134)
		dw	DUMMY_IRQ	; $FFF4 - IRQT2(134)
		dw	IRQ	; $FFF6 - IRQ1(134)
		dw      IRQ	; $FFF8 - IRQ2(134)

					; Common 8 bit Vectors for all CPUs
		dw	DUMMY_IRQ	; $FFFA -  NMIRQ
		dw	START		; $FFFC -  RESET
		dw	IRQ		; $FFFE -  IRQ BRK

	ELSEIF	USING_02
VECTORS	SECTION OFFSET $FFFA
					;65C02 Interrupt Vectors
					; Common 8 bit Vectors for all CPUs

		dw	DUMMY_IRQ	; $FFFA -  NMIRQ (ALL)
		dw	START		; $FFFC -  RESET (ALL)
		dw	IRQ		; $FFFE -  IRQBRK (ALL)
	ENDIF
	ENDS

	END

