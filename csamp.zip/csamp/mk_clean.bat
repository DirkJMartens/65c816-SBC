REM Make Clean for 'C' code
REM 01/12/2004

del *.bin
del *.obj
del *.lst
del *.txt
del *.map
del *.sym
del *.scc

del *.tmp
del *.opt
pause