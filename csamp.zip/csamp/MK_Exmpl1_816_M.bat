REM 'C' 65c816 Example #1 Program for the Small thru Large Model
REM File: MKWDCStartup816.bat
REM 10/07/2003

del WDC_CStartup_816.obj
del WDC_CStartup_816.lst
del WDC_CStartup_816.sym
del exmpl1.obj
del exmpl1.lst
del exmpl1.sym
del *.opt
del *.tmp

WDC816AS -g -l -DUSING_816 -DMEDIUM WDC_CStartup_816
WDC816CC -lt -mm -bs -DUSING_816 exmpl1
WDCLN -c1000 -sz -hz -g -t -o exmpl1.bin WDC_CStartup_816.obj exmpl1.obj -lcm
WDCSYM exmpl1 > symbols_816M.txt
WDCOBJ exmpl1 > objects_816M.txt
REM ALL Done!
pause